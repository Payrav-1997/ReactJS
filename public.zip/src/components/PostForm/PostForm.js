import React, {useState} from 'react';

export default function PostForm({onSave}) {
    const [post, setPost] = useState({
        id: Date.now(),
        author: {
            avatar: 'https://lms.openjs.io/logo_js.svg',
            name: 'OpenJS',
        },
        content: '',
        photo: null,
        hit: false,
        likes: 0,
        likedByMe: false,
        hidden: false,
        tags: [],
        created: Date.now(),
    });

    const handleSubmit = (ev) => {
        ev.preventDefault();
        const tags = post.tags.map((value, index) => value.replace("#", ""))
            .filter((value, index) => value !== "");
        onSave({
            ...post,
            tags: tags.length > 0 ? tags : null,
        })
    };
    const handleChange = (ev) => {
        const { value } = ev.target;
        setPost((prevState) => ({ ...prevState, content: value }));;
    }
    const handleTagsChange = (ev) => {
        const {name, value } = ev.target;
        if (name === "tags") {
            const parsed = value.split(" ");
            setPost((prevState) => ({ ...prevState, [name]: parsed }));
            return;
       }
       
        setPost((prevState) => ({ ...prevState, [name]: value }));
    }
    return (
        <form onSubmit={handleSubmit}>
            <textarea
                value={post.content}
                onChange={handleChange}
            ></textarea>
            <input name="tags"
                value={post.tags?.join(' ')}
                onChange={handleTagsChange}
                placeholder="tags"
            ></input>
            <button>Ok</button>
        </form>
    )
};